package ca.mcgill.ecse321.eventregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
